/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lulu;

import static lulu.Lulu.jeuSuite_formeCorrecte;
import static lulu.Lulu.jeuTrain_afficheTrainCorrect;
import static lulu.Lulu.jeuCourse_joueurSuivant;
import static lulu.Lulu.jeuCourse_posJ1Correct;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;

/**
 *
 * @author William Tchang
 */
public class TestLulu {

    @Test
    public void testJeuSuite_formeCorrecte() {
        assertEquals('t', jeuSuite_formeCorrecte(1));
        assertEquals('c', jeuSuite_formeCorrecte(2));
        assertEquals('c', jeuSuite_formeCorrecte(3));
    }

    @Test
    public void testJeuTrain_afficheTrainCorrect() {
        assertTrue(jeuTrain_afficheTrainCorrect(2, 2));
        assertTrue(jeuTrain_afficheTrainCorrect(1, 1));
        assertFalse(jeuTrain_afficheTrainCorrect(4, 0));
        assertFalse(jeuTrain_afficheTrainCorrect(2, 1));
        assertFalse(jeuTrain_afficheTrainCorrect(2, 4));
        assertFalse(jeuTrain_afficheTrainCorrect(3, 4));
    }

    @Test
    public void testJeuCourse_joueurSuivant() {
        assertEquals(2, jeuCourse_joueurSuivant(1));
        assertEquals(1, jeuCourse_joueurSuivant(2));
        assertFalse(jeuCourse_joueurSuivant(2) == 2);
        assertFalse(jeuCourse_joueurSuivant(1) == 1);
    }

    @Test
    public void testJeuCourse_posJ1Correct() {
        int posJ1 = 1;
        int posJ2 = 1;
        int posJ3 = 1;
        assertTrue(jeuCourse_posJ1Correct(1, posJ1, posJ2, posJ3, 2) == 1);
        assertTrue(jeuCourse_posJ1Correct(1, posJ1, posJ2, posJ3, 2) == 2);
        assertTrue(jeuCourse_posJ1Correct(1, posJ1, posJ2, posJ3, 2) == 3);

        posJ1 = 3;
        posJ2 = 1;
        posJ3 = 2;
        assertTrue(jeuCourse_posJ1Correct(1, posJ1, posJ2, posJ3, 2) == 3);
    }
}
